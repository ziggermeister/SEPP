# Yahoo Finance adapter
