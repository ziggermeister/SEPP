# Base provider adapter
