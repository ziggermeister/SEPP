# Alpha Vantage adapter
