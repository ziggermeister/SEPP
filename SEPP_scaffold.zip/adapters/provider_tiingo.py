# Tiingo adapter
